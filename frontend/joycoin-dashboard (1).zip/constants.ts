
import { CenterId } from './types';

export const JOYCOIN_PRICE_USD = 0.20;
export const REFERRAL_PERCENTAGE = 0.10;
export const CENTER_COMMISSION_PERCENTAGE = 0.10;
export const USDT_WALLET_ADDRESS = "0x742d35Cc6634C0532925a3b844Bc454e4438f44e"; // Mock USDT TRC20 Address
export const CENTERS: CenterId[] = ['A', 'B', 'C', 'D', 'E', 'F'];

export const INITIAL_CENTERS_DATA = CENTERS.map(id => ({
  centerId: id,
  totalMembers: 0,
  totalVolumeJoycoin: 0,
  totalCommissionUsdt: 0
}));

export type Language = 'EN' | 'KO' | 'TH';

export const TRANSLATIONS: Record<Language, any> = {
  EN: {
    landing_subtitle: "The Future of Happiness Capital",
    login: "LOGIN",
    signup: "SIGN UP",
    buy: "BUY",
    mypage: "My Page",
    super_admin: "Super Admin",
    center_admin: "Center Admin",
    logout: "Logout",
    available_balance: "AVAILABLE BALANCE",
    referral_rewards: "Referral Rewards",
    affiliated_sector: "Affiliated Sector",
    quick_access: "QUICK ACCESS",
    invite_friends: "INVITE FRIENDS",
    history_log: "HISTORY LOG",
    status_pending: "PENDING (WAITING)",
    status_completed: "COMPLETED (DEPOSITED)",
    buy_joycoin: "BUY JOYCOIN",
    select_start: "Select Starting Point",
    add_quantity: "Add to Quantity",
    order_summary: "Order Summary",
    proceed: "PROCEED TO PAYMENT",
    referrer_id: "Referrer ID",
    sector: "Sector",
    user_id: "User ID",
    password: "Password"
  },
  KO: {
    landing_subtitle: "행복 자본의 미래",
    login: "로그인",
    signup: "회원가입",
    buy: "구매하기",
    mypage: "마이페이지",
    super_admin: "총관리자",
    center_admin: "센터 관리자",
    logout: "로그아웃",
    available_balance: "보유 잔액",
    referral_rewards: "추천 보상",
    affiliated_sector: "소속 섹터",
    quick_access: "빠른 메뉴",
    invite_friends: "친구 초대",
    history_log: "거래 내역",
    status_pending: "구매대기",
    status_completed: "입금완료",
    buy_joycoin: "조이코인 구매",
    select_start: "시작 수량 선택",
    add_quantity: "수량 추가",
    order_summary: "주문 요약",
    proceed: "결제 진행하기",
    referrer_id: "추천인 아이디",
    sector: "추천 센터",
    user_id: "아이디",
    password: "비밀번호"
  },
  TH: {
    landing_subtitle: "อนาคตของทุนแห่งความสุข",
    login: "เข้าสู่ระบบ",
    signup: "ลงทะเบียน",
    buy: "ซื้อ",
    mypage: "หน้าของฉัน",
    super_admin: "ผู้ดูแลระบบสูงสุด",
    center_admin: "ผู้ดูแลศูนย์",
    logout: "ออกจากระบบ",
    available_balance: "ยอดเงินที่ใช้ได้",
    referral_rewards: "รางวัลการแนะนำ",
    affiliated_sector: "ภาคส่วนที่สังกัด",
    quick_access: "การเข้าถึงด่วน",
    invite_friends: "ชวนเพื่อน",
    history_log: "ประวัติการทำรายการ",
    status_pending: "รอดำเนินการ (รอ)",
    status_completed: "เสร็จสิ้น (ฝากแล้ว)",
    buy_joycoin: "ซื้อ JOYCOIN",
    select_start: "เลือกจุดเริ่มต้น",
    add_quantity: "เพิ่มจำนวน",
    order_summary: "สรุปคำสั่งซื้อ",
    proceed: "ดำเนินการชำระเงิน",
    referrer_id: "รหัสผู้แนะนำ",
    sector: "ภาคส่วน",
    user_id: "ชื่อผู้ใช้",
    password: "รหัสผ่าน"
  }
};
