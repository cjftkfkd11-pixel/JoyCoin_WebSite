
import React from 'react';
import { User, Transaction, TransactionStatus } from '../types';

interface MyPageProps {
  user: User;
  transactions: Transaction[];
  onBuy: () => void;
  onLogout: () => void;
  // Added translation function prop
  t: (key: string) => string;
}

const MyPage: React.FC<MyPageProps> = ({ user, transactions, onBuy, onLogout, t }) => {
  return (
    <div className="flex-1 max-w-6xl mx-auto w-full p-6 space-y-8 animate-in fade-in duration-700">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="glass p-10 rounded-[2.5rem] md:col-span-2 flex flex-col justify-between relative overflow-hidden border border-slate-800 shadow-2xl">
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-blue-600/10 rounded-full blur-[100px]"></div>
          <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-indigo-600/10 rounded-full blur-[100px]"></div>
          
          <div className="relative">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-slate-500 text-xs font-black uppercase tracking-[0.3em]">{t('available_balance')}</h3>
              <span className="bg-blue-600/10 text-blue-400 px-3 py-1 rounded-full text-[10px] font-black border border-blue-500/20">LIVE WALLET</span>
            </div>
            <div className="flex items-baseline space-x-4">
              <span className="text-8xl font-black text-white tracking-tighter">{user.joycoinBalance.toLocaleString()}</span>
              <span className="text-2xl font-black text-blue-500 italic">JOYCOIN</span>
            </div>
          </div>
          
          <div className="mt-12 flex space-x-12 relative border-t border-slate-800/50 pt-8">
             <div>
                <p className="text-slate-500 text-[10px] uppercase font-black tracking-widest mb-1">{t('referral_rewards')}</p>
                <p className="text-2xl font-black text-slate-200">{user.referralPoints.toLocaleString()} <span className="text-xs font-medium text-slate-500 tracking-normal">PTS</span></p>
             </div>
             <div>
                <p className="text-slate-500 text-[10px] uppercase font-black tracking-widest mb-1">{t('affiliated_sector')}</p>
                <p className="text-2xl font-black text-slate-200">SECTOR {user.centerId}</p>
             </div>
          </div>
        </div>

        <div className="flex flex-col gap-6">
          <div className="glass p-8 rounded-[2.5rem] flex-1 border border-slate-800 flex flex-col justify-center space-y-4">
            <h3 className="text-xl font-black italic text-white mb-2">{t('quick_access')}</h3>
            <button 
              onClick={onBuy}
              className="w-full py-5 bg-blue-600 hover:bg-blue-700 rounded-2xl font-black text-lg transition-all shadow-xl shadow-blue-500/20 active:scale-95 flex items-center justify-center space-x-3"
            >
              <span>{t('buy_joycoin')}</span>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
            </button>
            <button 
              className="w-full py-5 bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-2xl font-black transition-all active:scale-95"
              onClick={() => {
                navigator.clipboard.writeText(`https://joycoin.io/join?ref=${user.id}`);
                alert('Referral Link Copied!');
              }}
            >
              {t('invite_friends')}
            </button>
          </div>
        </div>
      </div>

      <div className="glass rounded-[2.5rem] overflow-hidden border border-slate-800 shadow-2xl">
        <div className="px-10 py-8 border-b border-slate-800 bg-slate-900/40 flex justify-between items-center">
          <h3 className="text-2xl font-black italic text-white">{t('history_log')}</h3>
          <div className="flex gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950 border border-slate-800">
               <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
               <span className="text-[10px] font-black text-slate-400 uppercase">Synced</span>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-950 text-slate-600 text-[10px] uppercase font-black tracking-[0.2em]">
              <tr>
                <th className="px-10 py-6">Reference ID</th>
                <th className="px-10 py-6">Timestamp</th>
                <th className="px-10 py-6">Quantity</th>
                <th className="px-10 py-6">Total Cost</th>
                <th className="px-10 py-6 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-10 py-24 text-center">
                    <div className="flex flex-col items-center space-y-4">
                       <svg className="w-12 h-12 text-slate-800" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                       <p className="text-slate-600 font-bold uppercase tracking-widest text-sm">No transaction records found</p>
                    </div>
                  </td>
                </tr>
              ) : (
                transactions.sort((a,b) => b.timestamp - a.timestamp).map(tx => (
                  <tr key={tx.id} className="hover:bg-slate-800/20 transition-colors">
                    <td className="px-10 py-7 font-mono text-xs text-slate-400">{tx.id}</td>
                    <td className="px-10 py-7 text-slate-500 font-medium text-sm">{new Date(tx.timestamp).toLocaleString()}</td>
                    <td className="px-10 py-7 font-black text-slate-200">{tx.amountJoycoin.toLocaleString()} JOY</td>
                    <td className="px-10 py-7 text-blue-500 font-black">{tx.amountUsdt.toFixed(2)} USDT</td>
                    <td className="px-10 py-7 text-right">
                      <span className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-sm ${
                        tx.status === TransactionStatus.COMPLETED ? 'bg-green-500/10 text-green-500 border border-green-500/20' :
                        tx.status === TransactionStatus.PENDING ? 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/20 animate-pulse' :
                        'bg-red-500/10 text-red-500 border border-red-500/20'
                      }`}>
                        {tx.status === TransactionStatus.COMPLETED ? t('status_completed') : t('status_pending')}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default MyPage;
