
import React, { useState } from 'react';
import { User, Transaction, TransactionStatus, CenterId } from '../types';
import { CENTERS } from '../constants';

interface AdminSuperProps {
  users: User[];
  transactions: Transaction[];
  centerRates: Record<CenterId, number>;
  onUpdateRate: (id: CenterId, rate: number) => void;
  onApprove: (txId: string) => void;
  onLogout: () => void;
  // Added translation function prop
  t: (key: string) => string;
}

const AdminSuper: React.FC<AdminSuperProps> = ({ users, transactions, centerRates, onUpdateRate, onApprove, t }) => {
  const [tab, setTab] = useState<'PENDING' | 'CENTERS' | 'LOGS'>('PENDING');
  const [selectedCenter, setSelectedCenter] = useState<CenterId | null>(null);

  const pendingTxs = transactions.filter(t => t.status === TransactionStatus.PENDING);
  
  const getCenterStats = (cid: CenterId) => {
    const centerUsers = users.filter(u => u.centerId === cid && u.role === 'USER');
    const centerTxs = transactions.filter(t => t.centerId === cid && t.status === TransactionStatus.COMPLETED);
    const volumeJoy = centerTxs.reduce((acc, t) => acc + t.amountJoycoin, 0);
    const volumeUsdt = centerTxs.reduce((acc, t) => acc + t.amountUsdt, 0);
    const rate = centerRates[cid];
    const commissionUsdt = volumeUsdt * rate;
    
    return { members: centerUsers.length, volumeJoy, volumeUsdt, commissionUsdt };
  };

  const rateOptions = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30];

  return (
    <div className="flex-1 p-6 max-w-7xl mx-auto w-full space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
           <h2 className="text-4xl font-black text-yellow-500 tracking-tighter">{t('super_admin')}</h2>
           <p className="text-slate-500 font-medium">Platform-wide overview & approval system</p>
        </div>
        <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800">
          <button 
            onClick={() => { setTab('PENDING'); setSelectedCenter(null); }}
            className={`px-6 py-2.5 rounded-xl font-bold transition-all text-sm ${tab === 'PENDING' ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'text-slate-500 hover:text-white'}`}
          >
            Pending ({pendingTxs.length})
          </button>
          <button 
            onClick={() => setTab('CENTERS')}
            className={`px-6 py-2.5 rounded-xl font-bold transition-all text-sm ${tab === 'CENTERS' ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'text-slate-500 hover:text-white'}`}
          >
            Sectors
          </button>
          <button 
            onClick={() => { setTab('LOGS'); setSelectedCenter(null); }}
            className={`px-6 py-2.5 rounded-xl font-bold transition-all text-sm ${tab === 'LOGS' ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'text-slate-500 hover:text-white'}`}
          >
            Audit Logs
          </button>
        </div>
      </div>

      {tab === 'PENDING' && (
        <div className="glass rounded-3xl overflow-hidden border border-slate-800 shadow-2xl">
          <div className="px-8 py-6 bg-slate-900/50 border-b border-slate-800 flex justify-between items-center">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse"></span>
              Waiting for Deposit Confirmation ({t('status_pending')})
            </h3>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Action Required</span>
          </div>
          <table className="w-full text-left">
            <thead className="bg-slate-900/80 text-slate-500 text-xs uppercase font-bold tracking-widest">
              <tr>
                <th className="px-8 py-4">Transaction Details</th>
                <th className="px-8 py-4">User Info</th>
                <th className="px-8 py-4 text-right">Payment</th>
                <th className="px-8 py-4 text-right">JOY Amount</th>
                <th className="px-8 py-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {pendingTxs.length === 0 ? (
                <tr><td colSpan={5} className="px-8 py-20 text-center text-slate-600 font-medium">All clear. No pending deposits.</td></tr>
              ) : (
                pendingTxs.map(tx => (
                  <tr key={tx.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="px-8 py-6">
                      <div className="font-mono text-xs text-slate-400 mb-1">{tx.id}</div>
                      <div className="text-xs text-slate-500">{new Date(tx.timestamp).toLocaleString()}</div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="font-bold text-white">{tx.userId}</div>
                      <div className="text-xs text-blue-500 font-bold">Sector {tx.centerId}</div>
                    </td>
                    <td className="px-8 py-6 text-right">
                       <div className="text-xl font-black text-blue-400">{tx.amountUsdt.toFixed(2)} <span className="text-xs">USDT</span></div>
                    </td>
                    <td className="px-8 py-6 text-right">
                       <div className="text-xl font-black text-slate-200">{tx.amountJoycoin.toLocaleString()} <span className="text-xs">JOY</span></div>
                    </td>
                    <td className="px-8 py-6 text-center">
                      <button 
                        onClick={() => onApprove(tx.id)}
                        className="px-6 py-2.5 bg-green-600 hover:bg-green-700 text-white font-black rounded-xl transition-all shadow-lg shadow-green-500/20 active:scale-95"
                      >
                        CONFIRM ({t('status_completed')})
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'CENTERS' && (
        <div className="space-y-6">
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {CENTERS.map(cid => {
              const stats = getCenterStats(cid);
              const isActive = selectedCenter === cid;
              const currentRate = centerRates[cid];
              
              return (
                <div 
                  key={cid} 
                  className={`glass p-6 rounded-3xl transition-all border-2 flex flex-col ${isActive ? 'border-yellow-500 ring-4 ring-yellow-500/10' : 'border-slate-800'}`}
                >
                  <div className="flex justify-between items-center mb-6 cursor-pointer" onClick={() => setSelectedCenter(cid)}>
                    <h4 className="text-2xl font-black text-white italic">SECTOR {cid}</h4>
                    <span className="bg-slate-900 px-3 py-1 rounded-full text-[10px] font-black uppercase text-slate-400 tracking-tighter">View Members</span>
                  </div>
                  
                  <div className="space-y-4 mb-6 cursor-pointer" onClick={() => setSelectedCenter(cid)}>
                    <div className="flex justify-between items-end">
                      <span className="text-slate-500 text-xs font-bold uppercase">Members</span>
                      <span className="text-2xl font-black text-white">{stats.members}</span>
                    </div>
                    <div className="flex justify-between items-end">
                      <span className="text-slate-500 text-xs font-bold uppercase">USDT Volume</span>
                      <span className="text-xl font-black text-blue-500">{stats.volumeUsdt.toLocaleString()} <span className="text-xs">USDT</span></span>
                    </div>
                    <div className="flex justify-between items-end border-t border-slate-800 pt-3">
                      <span className="text-slate-500 text-xs font-bold uppercase">Commission ({Math.round(currentRate * 100)}%)</span>
                      <span className="text-xl font-black text-green-400">{stats.commissionUsdt.toLocaleString()} <span className="text-xs text-green-600">USDT</span></span>
                    </div>
                  </div>

                  <div className="mt-auto border-t border-slate-800/50 pt-4 space-y-3">
                    <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest text-center">Adjust Sector Rate</p>
                    <div className="flex flex-wrap justify-center gap-1.5">
                      {rateOptions.map(r => (
                        <button
                          key={r}
                          onClick={() => onUpdateRate(cid, r)}
                          className={`px-2 py-1.5 rounded-lg text-[10px] font-black transition-all ${
                            currentRate === r 
                            ? 'bg-yellow-500 text-black shadow-md' 
                            : 'bg-slate-900 text-slate-500 hover:bg-slate-800'
                          }`}
                        >
                          {Math.round(r * 100)}%
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {selectedCenter && (
            <div className="glass rounded-3xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500 border border-slate-700 shadow-2xl">
              <div className="px-8 py-6 bg-slate-900/80 flex justify-between items-center border-b border-slate-700">
                <h3 className="text-xl font-black text-white">Sector {selectedCenter} Member List</h3>
                <button onClick={() => setSelectedCenter(null)} className="text-slate-500 hover:text-white">Close</button>
              </div>
              <table className="w-full text-left">
                <thead className="bg-slate-900/50 text-slate-500 text-xs font-bold uppercase tracking-widest">
                  <tr>
                    <th className="px-8 py-4">User ID</th>
                    <th className="px-8 py-4">Referrer</th>
                    <th className="px-8 py-4 text-right">Joycoin</th>
                    <th className="px-8 py-4 text-right">Points</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {users.filter(u => u.centerId === selectedCenter && u.role === 'USER').map(u => (
                    <tr key={u.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="px-8 py-5 font-black text-slate-200">{u.id}</td>
                      <td className="px-8 py-5 text-slate-500 font-medium">{u.referrerId || '—'}</td>
                      <td className="px-8 py-5 text-right font-black text-blue-400">{u.joycoinBalance.toLocaleString()}</td>
                      <td className="px-8 py-5 text-right font-bold text-slate-400">{u.referralPoints.toLocaleString()}</td>
                    </tr>
                  ))}
                  {users.filter(u => u.centerId === selectedCenter && u.role === 'USER').length === 0 && (
                    <tr><td colSpan={4} className="px-8 py-10 text-center text-slate-600">No members in this sector yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {tab === 'LOGS' && (
        <div className="glass rounded-3xl overflow-hidden border border-slate-800">
          <div className="px-8 py-6 bg-slate-900/50 flex justify-between items-center border-b border-slate-800">
            <h3 className="text-xl font-bold text-white italic">LIVE NETWORK FEED</h3>
            <div className="flex gap-2">
              <span className="flex items-center gap-2 bg-slate-950 px-3 py-1 rounded-full text-[10px] font-bold text-green-500">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-ping"></span>
                CONNECTED
              </span>
            </div>
          </div>
          <div className="p-4 max-h-[600px] overflow-y-auto font-mono text-[11px] space-y-2 bg-black/40">
            {[...transactions, ...users].sort((a: any, b: any) => (b.timestamp || 0) - (a.timestamp || 0)).map((item: any, idx) => (
               <div key={idx} className="group flex gap-4 text-slate-500 hover:bg-slate-800/20 p-2 rounded-lg transition-colors">
                 <span className="text-slate-700 whitespace-nowrap">[{new Date(item.timestamp || Date.now()).toISOString().split('T')[1].split('.')[0]}]</span>
                 {item.userId ? (
                   <div className="flex-1">
                     <span className="text-yellow-600 font-bold uppercase mr-2">Payment</span>
                     <span className="text-slate-300 font-bold">{item.userId}</span> in <span className="text-blue-600">Sector {item.centerId}</span>
                     {' -> '}
                     <span className={`font-bold ${item.status === 'COMPLETED' ? 'text-green-500' : 'text-blue-500 animate-pulse'}`}>
                       {item.status === 'COMPLETED' ? t('status_completed') : t('status_pending')}
                     </span>
                     {' '}
                     <span className="text-slate-400">val: {item.amountJoycoin} JOY</span>
                   </div>
                 ) : (
                   <div className="flex-1">
                     <span className="text-blue-500 font-bold uppercase mr-2">New Node</span>
                     <span className="text-slate-300 font-bold">{item.id}</span> connected to <span className="text-blue-600">Sector {item.centerId}</span>
                   </div>
                 )}
               </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminSuper;
