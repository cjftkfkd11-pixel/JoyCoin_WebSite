
import React, { useState } from 'react';
import { JOYCOIN_PRICE_USD, USDT_WALLET_ADDRESS } from '../constants';

interface BuyProps {
  onCreateTransaction: (joycoin: number, usdt: number) => void;
  onBack: () => void;
  // Added translation function prop
  t: (key: string) => string;
}

const Buy: React.FC<BuyProps> = ({ onCreateTransaction, onBack, t }) => {
  const [amount, setAmount] = useState(0);
  const [showPayment, setShowPayment] = useState(false);

  const handleIncrement = (val: number) => setAmount(prev => prev + val);
  const handleReset = (val: number) => setAmount(val);

  const usdtAmount = (amount * JOYCOIN_PRICE_USD).toFixed(2);

  const handleBuy = () => {
    if (amount <= 0) return;
    setShowPayment(true);
  };

  const confirmPayment = () => {
    onCreateTransaction(amount, parseFloat(usdtAmount));
    setShowPayment(false);
    onBack();
  };

  if (showPayment) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="glass p-8 rounded-3xl w-full max-w-md text-center space-y-6">
          <h2 className="text-2xl font-bold">Payment Confirmation</h2>
          <div className="bg-white p-4 rounded-2xl mx-auto w-48 h-48 flex items-center justify-center relative shadow-inner">
            {/* Mock QR Code */}
            <div className="grid grid-cols-6 gap-1 w-full h-full opacity-30">
               {[...Array(36)].map((_,i) => <div key={i} className="bg-black rounded-sm"></div>)}
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
               <span className="bg-white px-3 py-1 text-[10px] font-black tracking-widest border-2 border-slate-200">USDT TRC20</span>
            </div>
          </div>
          <div className="space-y-2">
            <p className="text-slate-400 text-sm font-medium">Send USDT (TRC20) to this address</p>
            <p className="text-4xl font-black text-blue-500">{usdtAmount} <span className="text-lg">USDT</span></p>
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 break-all font-mono text-xs text-blue-400 select-all">
              {USDT_WALLET_ADDRESS}
            </div>
          </div>
          <div className="pt-4 space-y-3">
            <button 
              onClick={confirmPayment}
              className="w-full py-4 bg-green-600 hover:bg-green-700 text-white font-black rounded-xl transition-all shadow-lg shadow-green-500/20 active:scale-95"
            >
              I HAVE TRANSFERRED USDT
            </button>
            <button 
              onClick={() => setShowPayment(false)}
              className="w-full py-4 bg-slate-800 text-slate-400 font-bold rounded-xl transition hover:text-white"
            >
              CANCEL
            </button>
          </div>
          <div className="bg-blue-500/10 border border-blue-500/20 p-4 rounded-xl">
             <p className="text-[10px] text-blue-400 font-bold uppercase leading-relaxed">
               Administrator will manually confirm the transaction upon arrival. 
               Status will be "PENDING (구매대기)" in My Page until confirmation.
             </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col items-center py-12 px-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="w-full max-w-3xl">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-6">
          <div>
            <h2 className="text-5xl font-black mb-3 italic tracking-tighter">{t('buy_joycoin')}</h2>
            <p className="text-slate-500 font-medium">Fixed Rate: <span className="text-white">1 JOY = $0.20 USDT</span></p>
          </div>
          <div className="text-right glass px-8 py-4 rounded-2xl border border-slate-800">
            <p className="text-xs text-slate-500 uppercase font-black tracking-widest mb-1">Subtotal (JOY)</p>
            <p className="text-6xl font-black text-blue-500 tracking-tighter">{amount.toLocaleString()}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-10">
            <div className="space-y-4">
              <label className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                {t('select_start')}
              </label>
              <div className="grid grid-cols-3 gap-3">
                {[1000, 5000, 10000].map(v => (
                  <button 
                    key={v}
                    onClick={() => handleReset(v)}
                    className={`py-4 rounded-2xl font-black transition-all border-2 ${amount === v ? 'bg-blue-600 border-blue-400 text-white shadow-xl shadow-blue-600/20' : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'}`}
                  >
                    {v.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <label className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                {t('add_quantity')}
              </label>
              <div className="grid grid-cols-3 gap-3">
                {[1000, 5000, 10000].map(v => (
                  <button 
                    key={v}
                    onClick={() => handleIncrement(v)}
                    className="py-4 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border-2 border-indigo-500/20 rounded-2xl font-black transition-all active:scale-95"
                  >
                    +{v.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="glass p-10 rounded-[2.5rem] flex flex-col justify-between border border-slate-800 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10">
               <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
            </div>
            
            <div className="space-y-6 relative">
              <h3 className="text-lg font-black italic text-slate-400 uppercase tracking-widest">{t('order_summary')}</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center text-slate-500 font-bold border-b border-slate-800 pb-4">
                  <span>Quantity</span>
                  <span className="text-white font-black">{amount.toLocaleString()} JOY</span>
                </div>
                <div className="flex justify-between items-center text-slate-500 font-bold border-b border-slate-800 pb-4">
                  <span>Price / JOY</span>
                  <span className="text-white font-black">$0.20 USDT</span>
                </div>
                <div className="flex justify-between items-end pt-4">
                  <span className="text-slate-300 font-black uppercase tracking-widest text-sm">Grand Total</span>
                  <div className="text-right">
                    <span className="text-4xl font-black text-blue-500">{usdtAmount}</span>
                    <span className="text-lg font-black text-blue-600 ml-2">USDT</span>
                  </div>
                </div>
              </div>
            </div>

            <button 
              onClick={handleBuy}
              disabled={amount <= 0}
              className="mt-12 w-full py-6 bg-blue-600 hover:bg-blue-500 disabled:opacity-30 disabled:grayscale text-white font-black text-2xl rounded-3xl shadow-2xl shadow-blue-600/30 transition-all active:scale-[0.98] uppercase tracking-tighter italic"
            >
              {t('proceed')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Buy;
