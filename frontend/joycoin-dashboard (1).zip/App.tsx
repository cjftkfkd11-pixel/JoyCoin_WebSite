
import React, { useState, useEffect } from 'react';
import { User, Transaction, TransactionStatus, CenterId } from './types';
import Landing from './components/Landing';
import Auth from './components/Auth';
import Buy from './components/Buy';
import MyPage from './components/MyPage';
import AdminCenter from './components/AdminCenter';
import AdminSuper from './components/AdminSuper';
import Layout from './components/Layout';
import { CENTERS, TRANSLATIONS, Language } from './constants';

const App: React.FC = () => {
  const [view, setView] = useState<'LANDING' | 'AUTH' | 'BUY' | 'MYPAGE' | 'ADMIN_CENTER' | 'ADMIN_SUPER'>('LANDING');
  const [authMode, setAuthMode] = useState<'LOGIN' | 'REGISTER' | 'ADMIN'>('LOGIN');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [language, setLanguage] = useState<Language>(() => (localStorage.getItem('joycoin_lang') as Language) || 'KO');
  
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  
  const t = (key: string) => TRANSLATIONS[language][key] || key;

  // Dynamic commission rates for each center (Default 10%)
  const [centerRates, setCenterRates] = useState<Record<CenterId, number>>(() => {
    const saved = localStorage.getItem('joycoin_center_rates');
    if (saved) return JSON.parse(saved);
    const defaults: any = {};
    CENTERS.forEach(id => defaults[id] = 0.10);
    return defaults;
  });

  useEffect(() => {
    const savedUsers = localStorage.getItem('joycoin_users');
    const savedTx = localStorage.getItem('joycoin_transactions');
    let currentUsers: User[] = savedUsers ? JSON.parse(savedUsers) : [];
    
    // Initialize Super Admin
    const existingAdmin = currentUsers.find(u => u.id === 'admin');
    if (!existingAdmin) {
      currentUsers.push({
        id: 'admin',
        password: 'a',
        centerId: 'A',
        joycoinBalance: 0,
        referralPoints: 0,
        role: 'SUPER_ADMIN'
      });
    } else {
      existingAdmin.password = 'a';
    }

    CENTERS.forEach(cid => {
      const adminId = `center_${cid.toLowerCase()}`;
      if (!currentUsers.find(u => u.id === adminId)) {
        currentUsers.push({
          id: adminId,
          password: `pass${cid}`,
          centerId: cid,
          managedCenterId: cid,
          joycoinBalance: 0,
          referralPoints: 0,
          role: 'CENTER_ADMIN'
        });
      }
    });

    setUsers(currentUsers);
    if (savedTx) setTransactions(JSON.parse(savedTx));
  }, []);

  useEffect(() => {
    if (users.length > 0) {
      localStorage.setItem('joycoin_users', JSON.stringify(users));
    }
    localStorage.setItem('joycoin_transactions', JSON.stringify(transactions));
    localStorage.setItem('joycoin_center_rates', JSON.stringify(centerRates));
    localStorage.setItem('joycoin_lang', language);
  }, [users, transactions, centerRates, language]);

  const handleLogin = (id: string, pass: string) => {
    const user = users.find(u => u.id === id && u.password === pass);
    if (user) {
      setCurrentUser(user);
      if (user.role === 'SUPER_ADMIN') setView('ADMIN_SUPER');
      else if (user.role === 'CENTER_ADMIN') setView('ADMIN_CENTER');
      else setView('MYPAGE');
      return true;
    }
    return false;
  };

  const handleRegister = (id: string, pass: string, referrer: string, center: CenterId) => {
    if (users.find(u => u.id === id)) return false;
    const newUser: User = {
      id,
      password: pass,
      referrerId: referrer || undefined,
      centerId: center,
      joycoinBalance: 0,
      referralPoints: 0,
      role: 'USER'
    };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    setView('MYPAGE');
    return true;
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setView('LANDING');
  };

  const handleGlobalBack = () => {
    if (view === 'AUTH') setView('LANDING');
    else if (view === 'BUY') setView('MYPAGE');
    else if (view === 'MYPAGE') setView('LANDING');
    else if (view === 'ADMIN_SUPER' || view === 'ADMIN_CENTER') setView('LANDING');
    else setView('LANDING');
  };

  const createTransaction = (amountJoycoin: number, amountUsdt: number) => {
    if (!currentUser) return;
    const newTx: Transaction = {
      id: `TX-${Date.now()}`,
      userId: currentUser.id,
      amountJoycoin,
      amountUsdt,
      timestamp: Date.now(),
      status: TransactionStatus.PENDING,
      centerId: currentUser.centerId
    };
    setTransactions(prev => [...prev, newTx]);
    
    alert(`[TELEGRAM NOTICE] New deposit request: ${amountUsdt} USDT from User ${currentUser.id}. Admin has been notified.`);
  };

  const approveTransaction = (txId: string) => {
    setTransactions(prev => prev.map(t => t.id === txId ? { ...t, status: TransactionStatus.COMPLETED } : t));

    const tx = transactions.find(t => t.id === txId);
    if (!tx) return;

    setUsers(prev => prev.map(u => {
      if (u.id === tx.userId) {
        return { ...u, joycoinBalance: u.joycoinBalance + tx.amountJoycoin };
      }
      
      const buyer = prev.find(b => b.id === tx.userId);
      if (buyer && buyer.referrerId && u.id === buyer.referrerId) {
          return { ...u, referralPoints: u.referralPoints + (tx.amountJoycoin * 0.1) };
      }
      return u;
    }));
  };

  const updateCenterRate = (id: CenterId, rate: number) => {
    setCenterRates(prev => ({ ...prev, [id]: rate }));
  };

  const renderContent = () => {
    switch (view) {
      case 'LANDING':
        return <Landing 
          onLogin={() => { setAuthMode('LOGIN'); setView('AUTH'); }} 
          onRegister={() => { setAuthMode('REGISTER'); setView('AUTH'); }} 
          onBuy={() => {
            if (currentUser) {
              setView('BUY');
            } else {
              setAuthMode('LOGIN');
              setView('AUTH');
            }
          }} 
          language={language}
          onLanguageChange={setLanguage}
          t={t}
        />;
      case 'AUTH':
        return <Auth mode={authMode} onChangeMode={(m) => setAuthMode(m)} onLogin={handleLogin} onRegister={handleRegister} t={t} />;
      case 'BUY':
        return <Buy onCreateTransaction={createTransaction} onBack={() => setView('MYPAGE')} t={t} />;
      case 'MYPAGE':
        return <MyPage user={currentUser!} transactions={transactions.filter(t => t.userId === currentUser?.id)} onBuy={() => setView('BUY')} onLogout={handleLogout} t={t} />;
      case 'ADMIN_CENTER':
        return <AdminCenter user={currentUser!} users={users} transactions={transactions} centerRates={centerRates} onLogout={handleLogout} t={t} />;
      case 'ADMIN_SUPER':
        return <AdminSuper users={users} transactions={transactions} centerRates={centerRates} onUpdateRate={updateCenterRate} onApprove={approveTransaction} onLogout={handleLogout} t={t} />;
      default:
        return null;
    }
  };

  return (
    <Layout 
      currentUser={currentUser} 
      onNavigate={(v: any) => setView(v)} 
      onLogout={handleLogout} 
      language={language} 
      onLanguageChange={setLanguage}
      t={t}
      currentView={view}
      onBack={handleGlobalBack}
    >
      {renderContent()}
    </Layout>
  );
};

export default App;
