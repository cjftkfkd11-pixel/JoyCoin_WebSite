
import React from 'react';
import { User, Transaction, TransactionStatus, CenterId } from '../types';

interface AdminCenterProps {
  user: User;
  users: User[];
  transactions: Transaction[];
  centerRates: Record<CenterId, number>;
  onLogout: () => void;
  // Added translation function prop
  t: (key: string) => string;
}

const AdminCenter: React.FC<AdminCenterProps> = ({ user, users, transactions, centerRates, t }) => {
  const centerId = user.managedCenterId || user.centerId;
  const centerMembers = users.filter(u => u.centerId === centerId && u.role === 'USER');
  const centerTxs = transactions.filter(t => t.centerId === centerId && t.status === TransactionStatus.COMPLETED);
  
  const totalVolumeJoy = centerTxs.reduce((acc, t) => acc + t.amountJoycoin, 0);
  const totalVolumeUsdt = centerTxs.reduce((acc, t) => acc + t.amountUsdt, 0);
  
  const currentRate = centerRates[centerId];
  const totalCommissionUsdt = totalVolumeUsdt * currentRate;

  return (
    <div className="flex-1 p-6 max-w-7xl mx-auto w-full space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-end border-b border-slate-800 pb-8">
        <div>
          <h2 className="text-4xl font-black text-white italic tracking-tighter">SECTOR {centerId}</h2>
          <p className="text-slate-500 font-medium mt-1">Local Distribution Management Hub</p>
        </div>
        <div className="text-right glass px-6 py-3 rounded-2xl border border-slate-800">
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">Admin ID</p>
          <p className="font-mono text-blue-400 font-bold">{user.id}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass p-8 rounded-3xl border border-slate-800">
          <div className="flex justify-between items-start mb-4">
             <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">Active Members</p>
             <div className="w-2 h-2 rounded-full bg-blue-500 shadow-lg shadow-blue-500/50"></div>
          </div>
          <p className="text-5xl font-black text-white">{centerMembers.length}</p>
        </div>
        
        <div className="glass p-8 rounded-3xl border border-slate-800">
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-4">JOY Distribution</p>
          <div className="flex items-baseline gap-2">
            <p className="text-5xl font-black text-white">{totalVolumeJoy.toLocaleString()}</p>
            <p className="text-xl font-bold text-blue-500">JOY</p>
          </div>
        </div>
        
        <div className="glass p-8 rounded-3xl border border-slate-800 border-l-4 border-l-green-500 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-3">
             <span className="bg-green-500/10 text-green-500 text-[10px] font-black px-2 py-1 rounded-lg border border-green-500/20">
               {Math.round(currentRate * 100)}% RATE
             </span>
          </div>
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-4">Your Commission</p>
          <div className="flex items-baseline gap-2">
            <p className="text-5xl font-black text-green-400">{totalCommissionUsdt.toLocaleString()}</p>
            <p className="text-xl font-bold text-green-600">USDT</p>
          </div>
          <p className="text-[10px] text-slate-600 font-medium mt-4 italic">Calculated from total sector volume of {totalVolumeUsdt.toLocaleString()} USDT</p>
        </div>
      </div>

      <div className="glass rounded-3xl overflow-hidden border border-slate-800 shadow-xl">
        <div className="px-10 py-6 bg-slate-900/50 border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-xl font-black text-white italic">SECTOR MEMBER LOG</h3>
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Auto-updating</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-900/80 text-slate-600 text-[10px] uppercase font-black tracking-widest">
              <tr>
                <th className="px-10 py-5">Identified Node</th>
                <th className="px-10 py-5">Sponsoring ID</th>
                <th className="px-10 py-5 text-right">JOY Holdings</th>
                <th className="px-10 py-5 text-right">Reward Points</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {centerMembers.length === 0 ? (
                 <tr><td colSpan={4} className="px-10 py-20 text-center text-slate-600 font-bold uppercase tracking-widest">No Sector Activity Detected</td></tr>
              ) : (
                centerMembers.map(u => (
                  <tr key={u.id} className="hover:bg-slate-800/20 transition-colors">
                    <td className="px-10 py-6">
                       <span className="font-black text-white">{u.id}</span>
                       <span className="ml-2 bg-blue-500/10 text-blue-500 text-[8px] px-1.5 py-0.5 rounded border border-blue-500/20">MEMBER</span>
                    </td>
                    <td className="px-10 py-6 text-slate-500 font-mono text-sm">{u.referrerId || 'DIRECT'}</td>
                    <td className="px-10 py-6 text-right font-black text-slate-200">{u.joycoinBalance.toLocaleString()} <span className="text-[10px] text-slate-500">JOY</span></td>
                    <td className="px-10 py-6 text-right font-bold text-blue-400">{u.referralPoints.toLocaleString()} <span className="text-[10px] text-blue-600">PTS</span></td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminCenter;
