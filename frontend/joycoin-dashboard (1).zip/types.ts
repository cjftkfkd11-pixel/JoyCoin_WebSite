
export type CenterId = 'A' | 'B' | 'C' | 'D' | 'E' | 'F';

export enum TransactionStatus {
  PENDING = 'PENDING',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

export interface User {
  id: string;
  password: string;
  referrerId?: string;
  centerId: CenterId;
  joycoinBalance: number;
  referralPoints: number;
  role: 'USER' | 'CENTER_ADMIN' | 'SUPER_ADMIN';
  managedCenterId?: CenterId;
}

export interface Transaction {
  id: string;
  userId: string;
  amountJoycoin: number;
  amountUsdt: number;
  timestamp: number;
  status: TransactionStatus;
  centerId: CenterId;
}

export interface CenterStats {
  centerId: CenterId;
  totalMembers: number;
  totalVolumeJoycoin: number;
  totalCommissionUsdt: number;
}
