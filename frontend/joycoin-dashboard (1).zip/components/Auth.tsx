
import React, { useState } from 'react';
import { CenterId } from '../types';
import { CENTERS } from '../constants';

interface AuthProps {
  mode: 'LOGIN' | 'REGISTER' | 'ADMIN';
  onChangeMode: (mode: 'LOGIN' | 'REGISTER' | 'ADMIN') => void;
  onLogin: (id: string, pass: string) => boolean;
  onRegister: (id: string, pass: string, ref: string, center: CenterId) => boolean;
  t: (key: string) => string;
}

const Auth: React.FC<AuthProps> = ({ mode, onChangeMode, onLogin, onRegister, t }) => {
  const [id, setId] = useState('');
  const [pass, setPass] = useState('');
  const [ref, setRef] = useState('');
  const [center, setCenter] = useState<CenterId>('A');
  const [adminType, setAdminType] = useState<'SUPER' | CenterId>('SUPER');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (mode === 'LOGIN') {
      const success = onLogin(id, pass);
      if (!success) setError('Invalid ID or Password');
    } else if (mode === 'REGISTER') {
      if (!id || !pass) {
        setError('Please fill required fields');
        return;
      }
      const success = onRegister(id, pass, ref, center);
      if (!success) setError('ID already exists');
    } else if (mode === 'ADMIN') {
      const adminId = adminType === 'SUPER' ? 'admin' : `center_${adminType.toLowerCase()}`;
      const success = onLogin(adminId, pass);
      if (!success) setError('Invalid Admin Credentials');
    }
  };

  return (
    <div className="flex-1 flex items-center justify-center px-4 py-12">
      <div className="glass p-8 md:p-12 rounded-3xl w-full max-w-md shadow-2xl border border-slate-700/50">
        <h2 className="text-3xl font-bold mb-8 text-center text-white">
          {mode === 'LOGIN' && t('login')}
          {mode === 'REGISTER' && t('signup')}
          {mode === 'ADMIN' && 'Admin Access'}
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-5">
          {mode === 'ADMIN' ? (
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2 uppercase tracking-wider">Admin Role</label>
              <select 
                value={adminType} 
                onChange={(e) => setAdminType(e.target.value as any)}
                className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3.5 focus:ring-2 focus:ring-blue-500 outline-none transition text-white"
              >
                <option value="SUPER">Total Manager (Super Admin)</option>
                {CENTERS.map(c => <option key={c} value={c}>Sector {c} Admin</option>)}
              </select>
            </div>
          ) : (
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2 uppercase tracking-wider">{t('user_id')}</label>
              <input 
                type="text" 
                value={id} 
                onChange={(e) => setId(e.target.value)}
                className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3.5 focus:ring-2 focus:ring-blue-500 outline-none transition text-white"
                placeholder="ID"
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-400 mb-2 uppercase tracking-wider">{t('password')}</label>
            <input 
              type="password" 
              value={pass} 
              onChange={(e) => setPass(e.target.value)}
              className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3.5 focus:ring-2 focus:ring-blue-500 outline-none transition text-white"
              placeholder="••••••••"
            />
          </div>

          {mode === 'REGISTER' && (
            <>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2 uppercase tracking-wider">{t('referrer_id')}</label>
                <input 
                  type="text" 
                  value={ref} 
                  onChange={(e) => setRef(e.target.value)}
                  className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3.5 focus:ring-2 focus:ring-blue-500 outline-none transition text-white"
                  placeholder="Referrer (Optional)"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2 uppercase tracking-wider">{t('sector')}</label>
                <select 
                  value={center} 
                  onChange={(e) => setCenter(e.target.value as CenterId)}
                  className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3.5 focus:ring-2 focus:ring-blue-500 outline-none transition text-white"
                >
                  {CENTERS.map(c => <option key={c} value={c}>Sector {c}</option>)}
                </select>
              </div>
            </>
          )}

          {error && <p className="text-red-400 text-sm text-center font-bold bg-red-500/10 py-3 rounded-xl border border-red-500/20">{error}</p>}

          <button 
            type="submit"
            className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-black text-lg rounded-xl shadow-lg shadow-blue-500/20 transition-all active:scale-[0.98]"
          >
            {mode === 'LOGIN' && t('login')}
            {mode === 'REGISTER' && t('signup')}
            {mode === 'ADMIN' && 'ADMIN LOGIN'}
          </button>
        </form>

        <div className="mt-10 pt-6 border-t border-slate-800 text-center">
            <div className="flex flex-wrap justify-center gap-6 text-sm font-bold uppercase tracking-widest">
                {mode !== 'LOGIN' && (
                    <button onClick={() => onChangeMode('LOGIN')} className="text-slate-500 hover:text-white transition">
                        Login
                    </button>
                )}
                {mode !== 'REGISTER' && (
                    <button onClick={() => onChangeMode('REGISTER')} className="text-blue-500 hover:text-blue-400 transition underline underline-offset-4">
                        Sign up
                    </button>
                )}
                {mode !== 'ADMIN' && (
                    <button onClick={() => onChangeMode('ADMIN')} className="text-yellow-500 hover:text-yellow-400 transition underline underline-offset-4">
                        Admin Login
                    </button>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;
