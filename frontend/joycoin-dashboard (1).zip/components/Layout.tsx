
import React from 'react';
import { User } from '../types';
import { Language } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  currentUser: User | null;
  onNavigate: (view: any) => void;
  onLogout: () => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  t: (key: string) => string;
  currentView: string;
  onBack: () => void;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  currentUser, 
  onNavigate, 
  onLogout, 
  language, 
  onLanguageChange, 
  t, 
  currentView,
  onBack
}) => {
  const isLanding = currentView === 'LANDING';

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Global Header / Navigation Layer */}
      <div className="fixed top-0 left-0 right-0 z-[60] px-4 md:px-10 py-5 flex justify-between items-center pointer-events-none">
        <div className="flex items-center space-x-4 pointer-events-auto">
          {/* Back Button - Visible everywhere except Landing */}
          {!isLanding && (
            <button 
              onClick={onBack}
              className="glass p-3 rounded-2xl border border-white/20 text-white hover:bg-white/10 transition-all active:scale-90 shadow-xl group"
              aria-label="Back"
            >
              <svg className="w-6 h-6 transform group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7" />
              </svg>
            </button>
          )}
          
          {/* Brand Logo - Only show if not on landing or on desktop */}
          {(!isLanding || currentUser) && (
            <span 
              className="text-2xl md:text-3xl font-black tracking-tighter text-blue-500 cursor-pointer drop-shadow-lg" 
              onClick={() => onNavigate('LANDING')}
            >
              JOYCOIN
            </span>
          )}
        </div>

        {/* Global Language Switcher & Nav (Desktop) */}
        <div className="flex items-center space-x-4 pointer-events-auto">
          {currentUser && (
            <nav className="hidden lg:flex items-center space-x-8 text-base font-bold text-white/80 mr-4">
              <button onClick={() => onNavigate('MYPAGE')} className="hover:text-blue-400 transition-colors">{t('mypage')}</button>
              <button onClick={() => onNavigate('BUY')} className="hover:text-blue-400 transition-colors">{t('buy')}</button>
              {currentUser.role === 'SUPER_ADMIN' && (
                <button onClick={() => onNavigate('ADMIN_SUPER')} className="text-yellow-500 hover:text-yellow-400 transition-colors">{t('super_admin')}</button>
              )}
              {currentUser.role === 'CENTER_ADMIN' && (
                <button onClick={() => onNavigate('ADMIN_CENTER')} className="text-green-500 hover:text-green-400 transition-colors">{t('center_admin')}</button>
              )}
            </nav>
          )}

          {/* Large Language Switcher - Also available in layout for consistency */}
          <div className="flex bg-black/40 p-1 rounded-2xl border border-white/10 backdrop-blur-md shadow-2xl">
            {(['EN', 'KO', 'TH'] as Language[]).map(lang => (
              <button
                key={lang}
                onClick={() => onLanguageChange(lang)}
                className={`px-3 py-1.5 md:px-4 md:py-2 rounded-xl text-[10px] md:text-[12px] font-black transition-all ${
                  language === lang 
                    ? 'bg-blue-600 text-white shadow-lg' 
                    : 'text-slate-500 hover:text-white'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>

          {currentUser && (
            <button onClick={onLogout} className="bg-red-500/20 text-red-400 px-4 py-2 rounded-2xl border border-red-500/30 hover:bg-red-500/30 transition-all active:scale-95 font-bold text-sm">
              {t('logout')}
            </button>
          )}
        </div>
      </div>

      <main className="flex-1 flex flex-col relative z-10 pt-20">
        {children}
      </main>

      <footer className="py-10 text-center text-slate-600 text-[10px] font-bold uppercase tracking-[0.3em] z-10">
        &copy; 2024 JOYCOIN GLOBAL FOUNDATION • SECURED BY BLOCKCHAIN
      </footer>
    </div>
  );
};

export default Layout;
